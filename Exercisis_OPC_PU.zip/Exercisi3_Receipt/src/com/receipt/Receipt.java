package com.receipt;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Clase que representa un recibo con líneas de items e impuestos.
 * El recibo comienza abierto y se cierra cuando se aplican los impuestos.
 */
public class Receipt {
    private BigDecimal subtotal;
    private BigDecimal total;
    private boolean closed;

    public Receipt() {
        this.subtotal = BigDecimal.ZERO;
        this.total = BigDecimal.ZERO;
        this.closed = false;
    }

    /**
     * Añade una línea al recibo con el precio unitario y cantidad.
     *
     * @param pricePerUnit Precio de una unidad
     * @param numUnits Número de unidades
     * @throws IsClosedException si el recibo está cerrado
     * @throws IllegalArgumentException si los parámetros son inválidos
     */
    public void addLine(BigDecimal pricePerUnit, int numUnits) throws IsClosedException {
        if (closed) {
            throw new IsClosedException("El recibo está cerrado");
        }
        if (pricePerUnit == null || numUnits < 0) {
            throw new IllegalArgumentException("Parámetros inválidos");
        }

        subtotal = subtotal.add(
                pricePerUnit.multiply(BigDecimal.valueOf(numUnits))
        );
    }

    /**
     * Añade impuestos al recibo y lo cierra.
     *
     * @param percent Porcentaje de impuesto a aplicar
     * @throws IsClosedException si el recibo ya está cerrado
     * @throws IllegalArgumentException si el porcentaje es inválido
     */
    public void addTaxes(BigDecimal percent) throws IsClosedException {
        if (closed) {
            throw new IsClosedException("El recibo está cerrado");
        }
        if (percent == null || percent.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("El porcentaje no puede ser negativo");
        }

        BigDecimal taxes = subtotal.multiply(percent)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        total = subtotal.add(taxes);
        closed = true;
    }

    /**
     * Obtiene el total del recibo (subtotal + impuestos si aplicados).
     * Puede llamarse en cualquier momento.
     *
     * @return Total del recibo
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * Verifica si el recibo está cerrado.
     *
     * @return true si está cerrado, false si está abierto
     */
    public boolean isClosed() {
        return closed;
    }
}