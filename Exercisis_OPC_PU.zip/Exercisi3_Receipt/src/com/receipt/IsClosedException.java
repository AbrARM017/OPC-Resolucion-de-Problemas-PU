package com.receipt;

public class IsClosedException extends Exception {
    public IsClosedException(String message) {
        super(message);
    }
}