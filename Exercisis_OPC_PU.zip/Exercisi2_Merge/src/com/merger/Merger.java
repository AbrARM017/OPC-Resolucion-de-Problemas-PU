package com.merger;

import java.util.*;

public class Merger {

    /**
     * Mezcla dos listas ordenadas de enteros crecientes y sin repetidos
     * en una única lista también ordenada y sin repetidos.
     *
     * @param list1 Primera lista ordenada y sin repetidos
     * @param list2 Segunda lista ordenada y sin repetidos
     * @return Lista fusionada, ordenada y sin repetidos
     * @throws IllegalArgumentException si alguna lista no está ordenada o tiene repetidos
     */
    public List<Integer> mergeSorted(List<Integer> list1, List<Integer> list2)
            throws IllegalArgumentException {
        validateList(list1);
        validateList(list2);

        List<Integer> result = new ArrayList<>();
        int i = 0, j = 0;

        while (i < list1.size() && j < list2.size()) {
            if (list1.get(i) < list2.get(j)) {
                result.add(list1.get(i++));
            } else {
                result.add(list2.get(j++));
            }
        }

        while (i < list1.size()) {
            result.add(list1.get(i++));
        }

        while (j < list2.size()) {
            result.add(list2.get(j++));
        }

        return result;
    }

    /**
     * Valida que la lista esté ordenada crecientemente y sin repetidos
     */
    private void validateList(List<Integer> list) throws IllegalArgumentException {
        if (list == null) {
            throw new IllegalArgumentException("La lista no puede ser null");
        }

        for (int i = 0; i < list.size() - 1; i++) {
            if (list.get(i) >= list.get(i + 1)) {
                throw new IllegalArgumentException(
                        "La lista no está ordenada o contiene repetidos"
                );
            }
        }
    }
}