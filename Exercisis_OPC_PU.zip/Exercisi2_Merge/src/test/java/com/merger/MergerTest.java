package test.java.com.merger;

import com.merger.Merger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;

@DisplayName("Tests para Merger")
public class MergerTest {
    private Merger merger;

    @BeforeEach
    public void setUp() {
        merger = new Merger();
    }

    // ===== Casos de Éxito =====

    @Test
    @DisplayName("Mezcla dos listas no vacías correctamente")
    public void testMergeTwoNonEmptyLists() {
        List<Integer> list1 = asList(1, 3, 5);
        List<Integer> list2 = asList(2, 4, 6);
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(asList(1, 2, 3, 4, 5, 6), result);
    }

    @Test
    @DisplayName("Primera lista vacía retorna segunda lista")
    public void testMergeFirstListEmpty() {
        List<Integer> list1 = emptyList();
        List<Integer> list2 = asList(1, 2, 3);
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(asList(1, 2, 3), result);
    }

    @Test
    @DisplayName("Segunda lista vacía retorna primera lista")
    public void testMergeSecondListEmpty() {
        List<Integer> list1 = asList(1, 2, 3);
        List<Integer> list2 = emptyList();
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(asList(1, 2, 3), result);
    }

    @Test
    @DisplayName("Ambas listas vacías retorna lista vacía")
    public void testMergeBothListsEmpty() {
        List<Integer> list1 = emptyList();
        List<Integer> list2 = emptyList();
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(emptyList(), result);
    }

    @Test
    @DisplayName("Mezcla listas con diferentes tamaños")
    public void testMergeWithDifferentSizes() {
        List<Integer> list1 = asList(1, 2, 3, 4, 5);
        List<Integer> list2 = asList(6, 7);
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(asList(1, 2, 3, 4, 5, 6, 7), result);
    }

    @Test
    @DisplayName("Mezcla listas con números negativos")
    public void testMergeWithNegativeNumbers() {
        List<Integer> list1 = asList(-5, -2, 0);
        List<Integer> list2 = asList(1, 3, 5);
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(asList(-5, -2, 0, 1, 3, 5), result);
    }

    @Test
    @DisplayName("Mezcla listas con elementos intercalados")
    public void testMergeWithInterleavedElements() {
        List<Integer> list1 = asList(1, 5, 9);
        List<Integer> list2 = asList(2, 4, 6, 8);
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(asList(1, 2, 4, 5, 6, 8, 9), result);
    }

    // ===== Casos de Error - Primera Lista =====

    @Test
    @DisplayName("Excepción si primera lista está desordenada")
    public void testMergeThrowsExceptionFirstListUnordered() {
        List<Integer> list1 = asList(3, 1, 2);
        List<Integer> list2 = asList(4, 5);
        assertThrows(IllegalArgumentException.class, () ->
                merger.mergeSorted(list1, list2)
        );
    }

    @Test
    @DisplayName("Excepción si primera lista tiene duplicados")
    public void testMergeThrowsExceptionFirstListWithDuplicates() {
        List<Integer> list1 = asList(1, 2, 2, 3);
        List<Integer> list2 = asList(4, 5);
        assertThrows(IllegalArgumentException.class, () ->
                merger.mergeSorted(list1, list2)
        );
    }

    @Test
    @DisplayName("Excepción si primera lista es null")
    public void testMergeThrowsExceptionFirstListNull() {
        assertThrows(IllegalArgumentException.class, () ->
                merger.mergeSorted(null, asList(1, 2))
        );
    }

    // ===== Casos de Error - Segunda Lista =====

    @Test
    @DisplayName("Excepción si segunda lista está desordenada")
    public void testMergeThrowsExceptionSecondListUnordered() {
        List<Integer> list1 = asList(1, 2, 3);
        List<Integer> list2 = asList(5, 4, 6);
        assertThrows(IllegalArgumentException.class, () ->
                merger.mergeSorted(list1, list2)
        );
    }

    @Test
    @DisplayName("Excepción si segunda lista tiene duplicados")
    public void testMergeThrowsExceptionSecondListWithDuplicates() {
        List<Integer> list1 = asList(1, 2, 3);
        List<Integer> list2 = asList(4, 4, 5);
        assertThrows(IllegalArgumentException.class, () ->
                merger.mergeSorted(list1, list2)
        );
    }

    @Test
    @DisplayName("Excepción si segunda lista es null")
    public void testMergeThrowsExceptionSecondListNull() {
        assertThrows(IllegalArgumentException.class, () ->
                merger.mergeSorted(asList(1, 2), null)
        );
    }

    // ===== Casos Fronterizos =====

    @Test
    @DisplayName("Lista con un único elemento")
    public void testMergeSingleElement() {
        List<Integer> list1 = asList(5);
        List<Integer> list2 = asList(3);
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(asList(3, 5), result);
    }

    @Test
    @DisplayName("Listas grandes")
    public void testMergeLargeLists() {
        List<Integer> list1 = asList(1, 3, 5, 7, 9, 11, 13, 15, 17, 19);
        List<Integer> list2 = asList(2, 4, 6, 8, 10, 12, 14, 16, 18, 20);
        List<Integer> result = merger.mergeSorted(list1, list2);
        assertEquals(
                asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20),
                result
        );
    }
}