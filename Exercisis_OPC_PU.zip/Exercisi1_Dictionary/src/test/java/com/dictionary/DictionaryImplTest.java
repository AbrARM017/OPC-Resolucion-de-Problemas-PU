package test.java.com.dictionary;

import com.dictionary.DictionaryImpl;
import com.dictionary.EmptyWordException;
import com.dictionary.NotDefinedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests para DictionaryImpl")
public class DictionaryImplTest {
    private DictionaryImpl dictionary;

    @BeforeEach
    public void setUp() {
        dictionary = new DictionaryImpl();
    }

    // ===== Pruebas para defineWord =====

    @Test
    @DisplayName("Agregar primera definición a una palabra")
    public void testDefineWordFirstDefinition() throws EmptyWordException {
        dictionary.defineWord("hola", "expresión de saludo");
        assertDoesNotThrow(() -> dictionary.getDefinitions("hola"));
    }

    @Test
    @DisplayName("Agregar múltiples definiciones a la misma palabra")
    public void testDefineWordMultipleDefinitions() throws EmptyWordException, NotDefinedException {
        dictionary.defineWord("banco", "institución financiera");
        dictionary.defineWord("banco", "mueble para sentarse");
        List<String> definitions = dictionary.getDefinitions("banco");
        assertEquals(2, definitions.size());
    }

    @Test
    @DisplayName("Lanzar excepción si la palabra es null")
    public void testDefineWordWithNullWord() {
        assertThrows(EmptyWordException.class, () ->
                dictionary.defineWord(null, "definición")
        );
    }

    @Test
    @DisplayName("Lanzar excepción si la palabra está vacía")
    public void testDefineWordWithEmptyWord() {
        assertThrows(EmptyWordException.class, () ->
                dictionary.defineWord("", "definición")
        );
    }

    @Test
    @DisplayName("Lanzar excepción si la palabra solo tiene espacios")
    public void testDefineWordWithBlankWord() {
        assertThrows(EmptyWordException.class, () ->
                dictionary.defineWord("   ", "definición")
        );
    }

    @Test
    @DisplayName("Lanzar excepción si la definición es null")
    public void testDefineWordWithNullDefinition() {
        assertThrows(EmptyWordException.class, () ->
                dictionary.defineWord("hola", null)
        );
    }

    @Test
    @DisplayName("Lanzar excepción si la definición está vacía")
    public void testDefineWordWithEmptyDefinition() {
        assertThrows(EmptyWordException.class, () ->
                dictionary.defineWord("hola", "")
        );
    }

    @Test
    @DisplayName("Palabras diferentes según mayúsculas/minúsculas")
    public void testDefineWordCaseSensitive() throws EmptyWordException, NotDefinedException {
        dictionary.defineWord("Hola", "con mayúscula");
        dictionary.defineWord("hola", "con minúscula");
        assertEquals(1, dictionary.getDefinitions("Hola").size());
        assertEquals(1, dictionary.getDefinitions("hola").size());
    }

    // ===== Pruebas para getDefinitions =====

    @Test
    @DisplayName("Obtener definición de palabra existente")
    public void testGetDefinitionsExistingWord() throws EmptyWordException, NotDefinedException {
        dictionary.defineWord("gato", "felino doméstico");
        List<String> definitions = dictionary.getDefinitions("gato");
        assertEquals(1, definitions.size());
        assertEquals("felino doméstico", definitions.get(0));
    }

    @Test
    @DisplayName("Lanzar excepción si la palabra no existe")
    public void testGetDefinitionsNonExistingWord() {
        assertThrows(NotDefinedException.class, () ->
                dictionary.getDefinitions("palabrainexistente")
        );
    }

    @Test
    @DisplayName("Obtener varias definiciones de una palabra")
    public void testGetDefinitionsMultipleDefinitions() throws EmptyWordException, NotDefinedException {
        dictionary.defineWord("libro", "objeto para leer");
        dictionary.defineWord("libro", "cantidad de folios");
        dictionary.defineWord("libro", "división de una obra literaria");
        List<String> definitions = dictionary.getDefinitions("libro");
        assertEquals(3, definitions.size());
    }

    @Test
    @DisplayName("getDefinitions retorna una copia, no la lista original")
    public void testGetDefinitionsReturnsNewList() throws EmptyWordException, NotDefinedException {
        dictionary.defineWord("test", "prueba");
        List<String> list1 = dictionary.getDefinitions("test");
        List<String> list2 = dictionary.getDefinitions("test");
        assertNotSame(list1, list2);
    }

    @Test
    @DisplayName("Diccionario vacío lanza excepción")
    public void testGetDefinitionsEmptyDictionary() {
        assertThrows(NotDefinedException.class, () ->
                dictionary.getDefinitions("cualquierpalabra")
        );
    }
}