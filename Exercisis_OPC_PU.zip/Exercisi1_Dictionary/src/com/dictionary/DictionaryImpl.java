package com.dictionary;

import java.util.*;

public class DictionaryImpl implements Dictionary {
    private Map<String, List<String>> dictionary;

    public DictionaryImpl() {
        this.dictionary = new HashMap<>();
    }

    @Override
    public void defineWord(String word, String definition) throws EmptyWordException {
        if (word == null || word.trim().isEmpty()) {
            throw new EmptyWordException("La palabra no puede estar vacía");
        }
        if (definition == null || definition.trim().isEmpty()) {
            throw new EmptyWordException("La definición no puede estar vacía");
        }

        dictionary.computeIfAbsent(word, k -> new ArrayList<>()).add(definition);
    }

    @Override
    public List<String> getDefinitions(String word) throws NotDefinedException {
        if (!dictionary.containsKey(word)) {
            throw new NotDefinedException("La palabra '" + word + "' no está en el diccionario");
        }
        return new ArrayList<>(dictionary.get(word));
    }
}