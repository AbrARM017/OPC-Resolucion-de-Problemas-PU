package com.receipt;

import java.math.BigDecimal;

/**
 * Interfaz para la base de datos de productos.
 * Define la abstracción que necesita Receipt para acceder a precios.
 */
public interface ProductsDB {
    /**
     * Obtiene el precio de un producto por su ID.
     *
     * @param productID Identificador del producto
     * @return Precio del producto
     * @throws DoesNotExistException si el producto no existe
     */
    BigDecimal getPrice(String productID) throws DoesNotExistException;
}