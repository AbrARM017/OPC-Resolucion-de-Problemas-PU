package com.task;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase abstracta para tareas compuestas por subtareas.
 * El coste es la suma de los costes de las subtareas.
 * La duración depende de la implementación (secuencial o paralela).
 */
public abstract class ComposedTask implements Task {
    protected List<Task> subtasks = new ArrayList<>();

    /**
     * Añade una subtarea a esta tarea compuesta.
     *
     * @param subtask La subtarea a añadir
     */
    public void addSubtask(Task subtask) {
        subtasks.add(subtask);
    }

    /**
     * Calcula el coste total como suma de costes de subtareas.
     *
     * @return Suma de costes de todas las subtareas
     */
    @Override
    public BigDecimal costInEuros() {
        return subtasks.stream()
                .map(Task::costInEuros)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Obtiene el número de subtareas.
     *
     * @return Número de subtareas
     */
    public int getSubtaskCount() {
        return subtasks.size();
    }
}