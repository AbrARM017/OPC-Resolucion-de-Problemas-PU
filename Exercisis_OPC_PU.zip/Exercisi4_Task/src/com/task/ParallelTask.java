package com.task;

/**
 * Tarea compuesta ejecutada en paralelo.
 * La duración es el máximo de las duraciones de las subtareas.
 */
public class ParallelTask extends ComposedTask {

    /**
     * Calcula la duración como el máximo de las duraciones de subtareas.
     *
     * @return Máxima duración entre todas las subtareas
     */
    @Override
    public int durationInDays() {
        return subtasks.stream()
                .mapToInt(Task::durationInDays)
                .max()
                .orElse(0);
    }
}