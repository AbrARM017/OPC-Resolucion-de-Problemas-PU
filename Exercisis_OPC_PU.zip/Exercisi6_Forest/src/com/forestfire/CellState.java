package com.forestfire;

/**
 * Enumera los posibles estados de una celda del bosque.
 */
public enum CellState {
    EMPTY,      // Celda vacía
    TREE,       // Contiene un árbol
    BURNING     // El árbol está ardiendo
}