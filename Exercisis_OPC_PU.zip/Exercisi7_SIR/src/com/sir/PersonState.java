package com.sir;

/**
 * Estados posibles de una persona en el modelo SIR.
 * S = Susceptible (puede infectarse)
 * I = Infected (está infectado)
 * R = Recovered (se recuperó e inmune)
 */
public enum PersonState {
    SUSCEPTIBLE,
    INFECTED,
    RECOVERED
}