package com.sir;

/**
 * Persona en modelo epidemiológico SIR.
 * Estados: Susceptible → Infected → Recovered
 */
public class Person {
    private static final double P_INFECTION = 0.01;
    private static final int DAYS_TO_RECOVER = 14;

    private PersonState state;
    private int daysInfected;
    private RandomProvider randomProvider;

    /**
     * Constructor: inicia como susceptible.
     *
     * @param randomProvider Proveedor de números aleatorios
     */
    public Person(RandomProvider randomProvider) {
        this.state = PersonState.SUSCEPTIBLE;
        this.daysInfected = 0;
        this.randomProvider = randomProvider;
    }

    /**
     * Obtiene el estado actual.
     *
     * @return Estado actual
     */
    public PersonState getState() {
        return state;
    }

    /**
     * Ejecuta un paso de la simulación.
     * - Si Susceptible: puede infectarse con probabilidad P_INFECTION
     * - Si Infected: cuenta días hasta llegar a DAYS_TO_RECOVER
     * - Si Recovered: permanece inmunizado
     */
    public void step() {
        switch (state) {
            case SUSCEPTIBLE:
                if (randomProvider.nextDouble() < P_INFECTION) {
                    state = PersonState.INFECTED;
                    daysInfected = 1;
                }
                break;

            case INFECTED:
                daysInfected++;
                if (daysInfected >= DAYS_TO_RECOVER) {
                    state = PersonState.RECOVERED;
                }
                break;

            case RECOVERED:
                // Inmunidad permanente
                break;
        }
    }
}