package test.java.com.sir;

import com.sir.RandomProvider;

/**
 * Mock de RandomProvider para modelo SIR.
 */
public class MockRandomProvider implements RandomProvider {
    private double[] values;
    private int index = 0;

    public MockRandomProvider(double[] values) {
        this.values = values;
    }

    @Override
    public double nextDouble() {
        if (index >= values.length) {
            throw new RuntimeException("No hay más valores en el mock");
        }
        return values[index++];
    }

    public void reset() {
        index = 0;
    }
}