package test.java.com.sir;

import com.sir.MockRandomProvider;
import com.sir.Person;
import com.sir.PersonState;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests para Person (Modelo SIR)")
public class PersonTest {

    @Test
    @DisplayName("Estado inicial es Susceptible")
    public void testInitialStateSusceptible() {
        Person person = new Person(new MockRandomProvider(new double[]{0.5}));
        assertEquals(PersonState.SUSCEPTIBLE, person.getState());
    }

    @Test
    @DisplayName("Susceptible se infecta con probabilidad")
    public void testSusceptibleToInfected() {
        // Valor < 0.01 → se infecta
        MockRandomProvider random = new MockRandomProvider(new double[]{0.005});
        Person person = new Person(random);

        person.step();

        assertEquals(PersonState.INFECTED, person.getState());
    }

    @Test
    @DisplayName("Susceptible no se infecta sin probabilidad")
    public void testSusceptibleStayIfNoInfection() {
        // Valor > 0.01 → no se infecta
        MockRandomProvider random = new MockRandomProvider(new double[]{0.02});
        Person person = new Person(random);

        person.step();

        assertEquals(PersonState.SUSCEPTIBLE, person.getState());
    }

    @Test
    @DisplayName("Infected se recupera después de 14 días")
    public void testInfectedRecovery() {
        // Primero infectamos, luego simulamos 14 días
        double[] values = new double[15];
        values[0] = 0.005; // Infectarse
        // Los siguientes 14 pueden ser cualquier cosa
        for (int i = 1; i < 15; i++) {
            values[i] = 0.5;
        }

        MockRandomProvider random = new MockRandomProvider(values);
        Person person = new Person(random);

        person.step(); // Día 1: infectarse
        assertEquals(PersonState.INFECTED, person.getState());

        // Días 2-13: sigue infectado
        for (int i = 0; i < 12; i++) {
            person.step();
            assertEquals(PersonState.INFECTED, person.getState(), "Debería estar infectado en día " + (i+2));
        }

        // Día 14: se recupera
        person.step();
        assertEquals(PersonState.RECOVERED, person.getState());
    }

    @Test
    @DisplayName("Recovered mantiene inmunidad")
    public void testRecoveredImmunity() {
        double[] values = new double[16];
        values[0] = 0.005; // Infectarse
        for (int i = 1; i < 16; i++) {
            values[i] = 0.001; // Intentos de reinfección (ignorados)
        }

        MockRandomProvider random = new MockRandomProvider(values);
        Person person = new Person(random);

        person.step(); // Infectarse

        // Recuperarse (14 pasos)
        for (int i = 0; i < 14; i++) {
            person.step();
        }
        assertEquals(PersonState.RECOVERED, person.getState());

        // Intentar infectar de nuevo (debe fallar)
        person.step();
        assertEquals(PersonState.RECOVERED, person.getState());
    }

    @Test
    @DisplayName("Ciclo completo: S → I → R")
    public void testCompleteSIRCycle() {
        double[] values = new double[16];
        values[0] = 0.001; // Infectarse
        for (int i = 1; i < 16; i++) {
            values[i] = 0.5;
        }

        MockRandomProvider random = new MockRandomProvider(values);
        Person person = new Person(random);

        // Inicial
        assertEquals(PersonState.SUSCEPTIBLE, person.getState());

        // Infectarse
        person.step();
        assertEquals(PersonState.INFECTED, person.getState());

        // 13 pasos más (total 14)
        for (int i = 0; i < 13; i++) {
            person.step();
        }

        // Recuperarse
        assertEquals(PersonState.RECOVERED, person.getState());
    }
}