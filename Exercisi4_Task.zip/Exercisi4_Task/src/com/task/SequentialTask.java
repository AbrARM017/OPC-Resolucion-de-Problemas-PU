package com.task;

/**
 * Tarea compuesta ejecutada secuencialmente.
 * La duración es la suma de las duraciones de las subtareas.
 */
public class SequentialTask extends ComposedTask {

    /**
     * Calcula la duración total como suma de duraciones de subtareas.
     *
     * @return Suma de duraciones de todas las subtareas
     */
    @Override
    public int durationInDays() {
        return subtasks.stream()
                .mapToInt(Task::durationInDays)
                .sum();
    }
}