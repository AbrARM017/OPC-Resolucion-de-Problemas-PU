package com.task;

import java.math.BigDecimal;

/**
 * Interfaz que representa una tarea con coste y duración.
 */
public interface Task {
    /**
     * Obtiene el coste de la tarea en euros.
     *
     * @return Coste de la tarea
     */
    BigDecimal costInEuros();

    /**
     * Obtiene la duración de la tarea en días.
     *
     * @return Duración en días
     */
    int durationInDays();
}