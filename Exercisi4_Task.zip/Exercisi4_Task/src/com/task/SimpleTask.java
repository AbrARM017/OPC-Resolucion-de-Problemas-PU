package com.task;

import java.math.BigDecimal;

/**
 * Tarea simple con coste y duración fijos.
 */
public class SimpleTask implements Task {
    private BigDecimal euros;
    private int days;

    /**
     * Constructor de una tarea simple.
     *
     * @param euros Coste de la tarea
     * @param days Duración de la tarea en días
     */
    public SimpleTask(BigDecimal euros, int days) {
        this.euros = euros;
        this.days = days;
    }

    @Override
    public BigDecimal costInEuros() {
        return euros;
    }

    @Override
    public int durationInDays() {
        return days;
    }
}