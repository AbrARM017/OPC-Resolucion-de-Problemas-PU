package test.java.com.task;

import com.task.ParallelTask;
import com.task.SequentialTask;
import com.task.SimpleTask;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;

@DisplayName("Tests para Task Scheduling")
public class TaskSchedulingTest {

    // ===== Tests para SimpleTask =====

    @Test
    @DisplayName("Obtener coste de tarea simple")
    public void testSimpleTaskCost() {
        SimpleTask task = new SimpleTask(BigDecimal.valueOf(100), 5);
        assertEquals(BigDecimal.valueOf(100), task.costInEuros());
    }

    @Test
    @DisplayName("Obtener duración de tarea simple")
    public void testSimpleTaskDuration() {
        SimpleTask task = new SimpleTask(BigDecimal.valueOf(100), 5);
        assertEquals(5, task.durationInDays());
    }

    @Test
    @DisplayName("Tarea simple con coste decimal")
    public void testSimpleTaskDecimalCost() {
        SimpleTask task = new SimpleTask(BigDecimal.valueOf(99.99), 3);
        assertEquals(BigDecimal.valueOf(99.99), task.costInEuros());
    }

    // ===== Tests para SequentialTask =====

    @Test
    @DisplayName("Coste de tarea secuencial es suma de subtareas")
    public void testSequentialTaskCost() {
        SequentialTask task = new SequentialTask();
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(50), 2));
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(30), 3));
        assertEquals(BigDecimal.valueOf(80), task.costInEuros());
    }

    @Test
    @DisplayName("Duración de tarea secuencial es suma de subtareas")
    public void testSequentialTaskDuration() {
        SequentialTask task = new SequentialTask();
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(50), 2));
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(30), 3));
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(20), 5));
        assertEquals(10, task.durationInDays());
    }

    @Test
    @DisplayName("Tarea secuencial vacía")
    public void testEmptySequentialTask() {
        SequentialTask task = new SequentialTask();
        assertEquals(BigDecimal.ZERO, task.costInEuros());
        assertEquals(0, task.durationInDays());
    }

    @Test
    @DisplayName("Tarea secuencial con una subtarea")
    public void testSequentialTaskSingleSubtask() {
        SequentialTask task = new SequentialTask();
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(100), 5));
        assertEquals(BigDecimal.valueOf(100), task.costInEuros());
        assertEquals(5, task.durationInDays());
    }

    // ===== Tests para ParallelTask =====

    @Test
    @DisplayName("Coste de tarea paralela es suma de subtareas")
    public void testParallelTaskCost() {
        ParallelTask task = new ParallelTask();
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(50), 2));
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(30), 3));
        assertEquals(BigDecimal.valueOf(80), task.costInEuros());
    }

    @Test
    @DisplayName("Duración de tarea paralela es máximo de subtareas")
    public void testParallelTaskDuration() {
        ParallelTask task = new ParallelTask();
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(50), 2));
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(30), 5));
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(20), 3));
        assertEquals(5, task.durationInDays());
    }

    @Test
    @DisplayName("Tarea paralela vacía")
    public void testEmptyParallelTask() {
        ParallelTask task = new ParallelTask();
        assertEquals(BigDecimal.ZERO, task.costInEuros());
        assertEquals(0, task.durationInDays());
    }

    @Test
    @DisplayName("Tarea paralela con una subtarea")
    public void testParallelTaskSingleSubtask() {
        ParallelTask task = new ParallelTask();
        task.addSubtask(new SimpleTask(BigDecimal.valueOf(100), 5));
        assertEquals(BigDecimal.valueOf(100), task.costInEuros());
        assertEquals(5, task.durationInDays());
    }

    // ===== Tests Anidados =====

    @Test
    @DisplayName("Tarea secuencial anidada con paralela")
    public void testNestedSequentialWithParallel() {
        SequentialTask mainTask = new SequentialTask();

        // Tarea paralela con 2 subtareas (duraciones 2 y 4, max=4)
        ParallelTask parallel = new ParallelTask();
        parallel.addSubtask(new SimpleTask(BigDecimal.valueOf(20), 2));
        parallel.addSubtask(new SimpleTask(BigDecimal.valueOf(30), 4));

        // Añadir paralela y otra tarea simple
        mainTask.addSubtask(parallel);
        mainTask.addSubtask(new SimpleTask(BigDecimal.valueOf(50), 3));

        // Coste: 20 + 30 + 50 = 100
        assertEquals(BigDecimal.valueOf(100), mainTask.costInEuros());

        // Duración: 4 + 3 = 7 (paralela dura 4, luego suma 3)
        assertEquals(7, mainTask.durationInDays());
    }

    @Test
    @DisplayName("Tarea paralela anidada con secuencial")
    public void testNestedParallelWithSequential() {
        ParallelTask mainTask = new ParallelTask();

        // Tarea secuencial con 2 subtareas (duraciones 2 y 3, suma=5)
        SequentialTask sequential = new SequentialTask();
        sequential.addSubtask(new SimpleTask(BigDecimal.valueOf(20), 2));
        sequential.addSubtask(new SimpleTask(BigDecimal.valueOf(30), 3));

        // Añadir secuencial y otra tarea simple
        mainTask.addSubtask(sequential);
        mainTask.addSubtask(new SimpleTask(BigDecimal.valueOf(50), 1));

        // Coste: 20 + 30 + 50 = 100
        assertEquals(BigDecimal.valueOf(100), mainTask.costInEuros());

        // Duración: max(5, 1) = 5 (paralela toma el máximo)
        assertEquals(5, mainTask.durationInDays());
    }

    @Test
    @DisplayName("Estructura compleja con múltiples niveles")
    public void testComplexNestedStructure() {
        SequentialTask mainTask = new SequentialTask();

        // Paralela 1: 2 tareas
        ParallelTask parallel1 = new ParallelTask();
        parallel1.addSubtask(new SimpleTask(BigDecimal.valueOf(10), 1));
        parallel1.addSubtask(new SimpleTask(BigDecimal.valueOf(10), 2));

        // Secuencial: 2 tareas
        SequentialTask seq = new SequentialTask();
        seq.addSubtask(new SimpleTask(BigDecimal.valueOf(10), 1));
        seq.addSubtask(new SimpleTask(BigDecimal.valueOf(10), 1));

        // Paralela 2: 2 tareas
        ParallelTask parallel2 = new ParallelTask();
        parallel2.addSubtask(new SimpleTask(BigDecimal.valueOf(10), 1));
        parallel2.addSubtask(new SimpleTask(BigDecimal.valueOf(10), 3));

        mainTask.addSubtask(parallel1);
        mainTask.addSubtask(seq);
        mainTask.addSubtask(parallel2);

        // Coste: 40 euros (todas las subtareas de 10)
        assertEquals(BigDecimal.valueOf(40), mainTask.costInEuros());

        // Duración: 2 (parallel1) + 2 (seq) + 3 (parallel2) = 7
        assertEquals(7, mainTask.durationInDays());
    }

    // ===== Tests Fronterizos =====

    @Test
    @DisplayName("Múltiples subtareas en tarea secuencial")
    public void testSequentialTaskMultipleSubtasks() {
        SequentialTask task = new SequentialTask();
        for (int i = 1; i <= 5; i++) {
            task.addSubtask(new SimpleTask(BigDecimal.valueOf(i * 10), i));
        }
        // Coste: 10 + 20 + 30 + 40 + 50 = 150
        assertEquals(BigDecimal.valueOf(150), task.costInEuros());
        // Duración: 1 + 2 + 3 + 4 + 5 = 15
        assertEquals(15, task.durationInDays());
    }

    @Test
    @DisplayName("Múltiples subtareas en tarea paralela")
    public void testParallelTaskMultipleSubtasks() {
        ParallelTask task = new ParallelTask();
        for (int i = 1; i <= 5; i++) {
            task.addSubtask(new SimpleTask(BigDecimal.valueOf(i * 10), i));
        }
        // Coste: 10 + 20 + 30 + 40 + 50 = 150
        assertEquals(BigDecimal.valueOf(150), task.costInEuros());
        // Duración: max(1, 2, 3, 4, 5) = 5
        assertEquals(5, task.durationInDays());
    }
}