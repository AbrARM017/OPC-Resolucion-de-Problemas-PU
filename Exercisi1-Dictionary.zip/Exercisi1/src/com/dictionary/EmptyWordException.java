package com.dictionary;

public class EmptyWordException extends Exception {
    public EmptyWordException(String message) {
        super(message);
    }
}