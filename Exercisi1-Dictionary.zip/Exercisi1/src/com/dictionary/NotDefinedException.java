package com.dictionary;

public class NotDefinedException extends Exception {
    public NotDefinedException(String message) {
        super(message);
    }
}