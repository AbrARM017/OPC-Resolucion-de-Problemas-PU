package com.dictionary;

import java.util.List;

public interface Dictionary {
    void defineWord(String word, String definition) throws EmptyWordException;
    List<String> getDefinitions(String word) throws NotDefinedException;
}