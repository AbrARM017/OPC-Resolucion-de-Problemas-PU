package com.forestfire;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests para Cell (Forest-Fire Model)")
public class CellTest {

    @Test
    @DisplayName("Celda inicial está vacía")
    public void testInitialStateEmpty() {
        Cell cell = new Cell(new MockRandomProvider(new double[]{0.5}));
        assertEquals(CellState.EMPTY, cell.getState());
    }

    @Test
    @DisplayName("Celda ardiendo pasa a vacía")
    public void testBurningToEmpty() {
        MockRandomProvider random = new MockRandomProvider(new double[]{});
        Cell cell = new Cell(random);

        // Cambiar estado manualmente a BURNING para este test
        setStateDirectly(cell, CellState.BURNING);

        cell.step(false);
        assertEquals(CellState.EMPTY, cell.getState());
    }

    @Test
    @DisplayName("Árbol con vecino ardiendo se quema")
    public void testTreeWithBurningNeighbor() {
        MockRandomProvider random = new MockRandomProvider(new double[]{0.5});
        Cell cell = new Cell(random);
        setStateDirectly(cell, CellState.TREE);

        cell.step(true); // Hay vecino ardiendo

        assertEquals(CellState.BURNING, cell.getState());
    }

    @Test
    @DisplayName("Árbol sin vecino ardiendo y sin combustión espontánea sigue siendo árbol")
    public void testTreeWithoutBurningNeighborStayTree() {
        // Valor > PBURN (0.00006) → sin combustión espontánea
        MockRandomProvider random = new MockRandomProvider(new double[]{0.0001});
        Cell cell = new Cell(random);
        setStateDirectly(cell, CellState.TREE);

        cell.step(false); // Sin vecino ardiendo

        assertEquals(CellState.TREE, cell.getState());
    }

    @Test
    @DisplayName("Árbol se quema por combustión espontánea")
    public void testTreeSpontaneousBurn() {
        // Valor < PBURN (0.00006) → combustión espontánea
        MockRandomProvider random = new MockRandomProvider(new double[]{0.00001});
        Cell cell = new Cell(random);
        setStateDirectly(cell, CellState.TREE);

        cell.step(false); // Sin vecino ardiendo, pero arde espontáneamente

        assertEquals(CellState.BURNING, cell.getState());
    }

    @Test
    @DisplayName("Espacio vacío crece árbol")
    public void testEmptyGrowthTree() {
        // Valor < PGROWTH (0.01) → crece árbol
        MockRandomProvider random = new MockRandomProvider(new double[]{0.005});
        Cell cell = new Cell(random);

        cell.step(false);

        assertEquals(CellState.TREE, cell.getState());
    }

    @Test
    @DisplayName("Espacio vacío sin crecimiento sigue vacío")
    public void testEmptyNoGrowth() {
        // Valor > PGROWTH (0.01) → no crece
        MockRandomProvider random = new MockRandomProvider(new double[]{0.02});
        Cell cell = new Cell(random);

        cell.step(false);

        assertEquals(CellState.EMPTY, cell.getState());
    }

    @Test
    @DisplayName("Ciclo completo: vacío → árbol → ardiendo → vacío")
    public void testCompleteLifeCycle() {
        MockRandomProvider random = new MockRandomProvider(
                new double[]{0.005, 0.00001} // Crece, luego se quema
        );
        Cell cell = new Cell(random);

        assertEquals(CellState.EMPTY, cell.getState());

        cell.step(false);
        assertEquals(CellState.TREE, cell.getState());

        cell.step(false); // Sin vecino, pero se quema espontáneamente
        assertEquals(CellState.BURNING, cell.getState());

        cell.step(false);
        assertEquals(CellState.EMPTY, cell.getState());
    }

    /**
     * Helper para cambiar el estado de una celda usando reflexión.
     * Solo para testing.
     */
    private void setStateDirectly(Cell cell, CellState state) {
        try {
            var field = Cell.class.getDeclaredField("state");
            field.setAccessible(true);
            field.set(cell, state);
        } catch (Exception e) {
            throw new RuntimeException("Error configurando estado: " + e.getMessage());
        }
    }
}