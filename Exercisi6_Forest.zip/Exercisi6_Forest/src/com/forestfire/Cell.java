package com.forestfire;

/**
 * Celda del modelo Forest-Fire.
 * Representa un pequeño espacio que puede estar vacío, tener árbol o arder.
 */
public class Cell {
    // Probabilidad de que un árbol se queme espontáneamente
    private static final double PBURN = 0.00006;

    // Probabilidad de que un árbol brote en espacio vacío
    private static final double PGROWTH = 0.01;

    private CellState state;
    private RandomProvider randomProvider;

    /**
     * Constructor de celda inicialmente vacía.
     *
     * @param randomProvider Proveedor de números aleatorios
     */
    public Cell(RandomProvider randomProvider) {
        this.state = CellState.EMPTY;
        this.randomProvider = randomProvider;
    }

    /**
     * Obtiene el estado actual de la celda.
     *
     * @return Estado actual
     */
    public CellState getState() {
        return state;
    }

    /**
     * Ejecuta un paso de la simulación actualizando el estado.
     * Reglas:
     * 1. Si está ardiendo → vacía
     * 2. Si árbol y hay vecino ardiendo → arde
     * 3. Si árbol → puede quemar espontáneamente
     * 4. Si vacío → puede crecer árbol
     *
     * @param hasBurningNeighbour true si algún vecino está ardiendo
     */
    public void step(boolean hasBurningNeighbour) {
        switch (state) {
            case CellState.BURNING:
                // Una celda ardiendo se convierte en vacía
                state = CellState.EMPTY;
                break;

            case CellState.TREE:
                // Un árbol arde si hay vecino ardiendo o por combustión espontánea
                if (hasBurningNeighbour || randomProvider.nextDouble() < PBURN) {
                    state = CellState.BURNING;
                }
                break;

            case CellState.EMPTY:
                // Un árbol puede brotar en espacio vacío
                if (randomProvider.nextDouble() < PGROWTH) {
                    state = CellState.TREE;
                }
                break;
        }
    }
}