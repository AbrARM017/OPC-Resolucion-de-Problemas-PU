package test.java.com.forestfire;

/**
 * Mock de RandomProvider para testing.
 * Permite controlar exactamente qué números aleatorios se generan.
 */
public class MockRandomProvider implements RandomProvider {
    private double[] values;
    private int index = 0;

    /**
     * Constructor con serie de valores predefinidos.
     *
     * @param values Array de valores que se retornarán secuencialmente
     */
    public MockRandomProvider(double[] values) {
        this.values = values;
    }

    /**
     * Retorna el siguiente valor de la serie.
     *
     * @return Siguiente valor
     * @throws RuntimeException si se agotan los valores
     */
    @Override
    public double nextDouble() {
        if (index >= values.length) {
            throw new RuntimeException("No hay más valores disponibles en el mock");
        }
        return values[index++];
    }

    /**
     * Reinicia el índice para reutilizar el mock.
     */
    public void reset() {
        index = 0;
    }
}