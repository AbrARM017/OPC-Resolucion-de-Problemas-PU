package test.java.com.forestfire;

/**
 * Interfaz para generar números aleatorios.
 * Permite inyectar diferentes implementaciones en tests.
 */
public interface RandomProvider {
    /**
     * Obtiene un número aleatorio entre 0.0 y 1.0.
     *
     * @return Número aleatorio
     */
    double nextDouble();
}