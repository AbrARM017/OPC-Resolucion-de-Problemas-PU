package com.sir;

public interface RandomProvider {
    double nextDouble();
}