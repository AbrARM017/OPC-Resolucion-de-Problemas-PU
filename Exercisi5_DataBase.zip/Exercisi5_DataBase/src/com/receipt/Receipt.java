package com.receipt;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Clase Receipt que depende de una base de datos de productos.
 * Permite agregar líneas con IDs de productos y calcular el total con impuestos.
 */
public class Receipt {
    private ProductsDB productsDB;
    private BigDecimal subtotal;
    private BigDecimal total;
    private boolean closed;

    /**
     * Constructor que inyecta la dependencia de base de datos.
     *
     * @param productsDB Implementación de ProductsDB a usar
     */
    public Receipt(ProductsDB productsDB) {
        this.productsDB = productsDB;
        this.subtotal = BigDecimal.ZERO;
        this.total = BigDecimal.ZERO;
        this.closed = false;
    }

    /**
     * Añade una línea al recibo consultando el precio en la base de datos.
     *
     * @param productID ID del producto
     * @param numUnits Número de unidades
     * @throws IsClosedException si el recibo está cerrado
     * @throws DoesNotExistException si el producto no existe en la BD
     * @throws IllegalArgumentException si los parámetros son inválidos
     */
    public void addLine(String productID, int numUnits)
            throws IsClosedException, DoesNotExistException {
        if (closed) {
            throw new IsClosedException("El recibo está cerrado");
        }
        if (numUnits < 0) {
            throw new IllegalArgumentException("Número de unidades no puede ser negativo");
        }

        // Consulta la BD para obtener el precio
        BigDecimal price = productsDB.getPrice(productID);

        // Suma al subtotal
        subtotal = subtotal.add(price.multiply(BigDecimal.valueOf(numUnits)));
    }

    /**
     * Aplica impuestos y cierra el recibo.
     *
     * @param percent Porcentaje de impuesto
     * @throws IsClosedException si el recibo ya está cerrado
     * @throws IllegalArgumentException si el porcentaje es inválido
     */
    public void addTaxes(BigDecimal percent) throws IsClosedException {
        if (closed) {
            throw new IsClosedException("El recibo ya está cerrado");
        }
        if (percent == null || percent.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("El porcentaje no puede ser negativo");
        }

        BigDecimal taxes = subtotal.multiply(percent)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        total = subtotal.add(taxes);
        closed = true;
    }

    /**
     * Obtiene el total del recibo.
     *
     * @return Total (subtotal + impuestos si aplicados)
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * Verifica si el recibo está cerrado.
     *
     * @return true si está cerrado, false si está abierto
     */
    public boolean isClosed() {
        return closed;
    }
}