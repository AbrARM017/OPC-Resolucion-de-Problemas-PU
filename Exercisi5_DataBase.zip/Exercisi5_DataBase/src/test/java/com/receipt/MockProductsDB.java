package com.receipt;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Mock (doble de prueba) de ProductsDB para testing.
 * Simula una base de datos en memoria sin dependencias externas.
 */
public class MockProductsDB implements ProductsDB {
    private Map<String, BigDecimal> prices = new HashMap<>();

    /**
     * Añade un producto al mock de BD.
     *
     * @param productID Identificador del producto
     * @param price Precio del producto
     */
    public void addProduct(String productID, BigDecimal price) {
        prices.put(productID, price);
    }

    /**
     * Simula la búsqueda de precio en la BD.
     *
     * @param productID ID del producto
     * @return Precio del producto
     * @throws DoesNotExistException si el producto no existe
     */
    @Override
    public BigDecimal getPrice(String productID) throws DoesNotExistException {
        if (!prices.containsKey(productID)) {
            throw new DoesNotExistException("Producto " + productID + " no encontrado");
        }
        return prices.get(productID);
    }
}