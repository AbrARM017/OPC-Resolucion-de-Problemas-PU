package test.java.com.receipt;

import com.receipt.DoesNotExistException;
import com.receipt.IsClosedException;
import com.receipt.MockProductsDB;
import com.receipt.Receipt;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;

@DisplayName("Tests para Receipt con MockProductsDB")
public class Receipt5Test {
    private Receipt receipt;
    private MockProductsDB mockDB;

    @BeforeEach
    public void setUp() {
        // Se crea un mock en lugar de una BD real
        mockDB = new MockProductsDB();
        receipt = new Receipt(mockDB);
    }

    // ===== Tests para addLine =====

    @Test
    @DisplayName("Agregar línea con producto válido")
    public void testAddLineWithValidProduct() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(10));
        receipt.addLine("P001", 2);
        assertFalse(receipt.isClosed());
    }

    @Test
    @DisplayName("Excepción si el producto no existe")
    public void testAddLineWithNonExistentProduct() {
        assertThrows(DoesNotExistException.class, () ->
                receipt.addLine("P999", 1)
        );
    }

    @Test
    @DisplayName("Agregar múltiples líneas con diferentes productos")
    public void testAddLineMultipleProducts() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(10));
        mockDB.addProduct("P002", BigDecimal.valueOf(20));
        mockDB.addProduct("P003", BigDecimal.valueOf(15));

        receipt.addLine("P001", 2);
        receipt.addLine("P002", 3);
        receipt.addLine("P003", 1);

        assertFalse(receipt.isClosed());
    }

    @Test
    @DisplayName("Agregar línea con cero unidades")
    public void testAddLineWithZeroUnits() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(10));
        receipt.addLine("P001", 0);
        assertFalse(receipt.isClosed());
    }

    @Test
    @DisplayName("Excepción si unidades negativas")
    public void testAddLineWithNegativeUnits() throws DoesNotExistException {
        mockDB.addProduct("P001", BigDecimal.valueOf(10));
        assertThrows(IllegalArgumentException.class, () ->
                receipt.addLine("P001", -1)
        );
    }

    @Test
    @DisplayName("Excepción si se agrega línea después de cerrar")
    public void testAddLineAfterClosing() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(100));
        receipt.addLine("P001", 1);
        receipt.addTaxes(BigDecimal.valueOf(21));

        assertThrows(IsClosedException.class, () ->
                receipt.addLine("P001", 1)
        );
    }

    // ===== Tests para addTaxes =====

    @Test
    @DisplayName("Aplicar impuestos cierra el recibo")
    public void testAddTaxesClosesReceipt() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(100));
        receipt.addLine("P001", 1);
        receipt.addTaxes(BigDecimal.valueOf(21));

        assertTrue(receipt.isClosed());
    }

    @Test
    @DisplayName("Excepción si se aplican impuestos dos veces")
    public void testAddTaxesAfterClosing() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(100));
        receipt.addLine("P001", 1);
        receipt.addTaxes(BigDecimal.valueOf(21));

        assertThrows(IsClosedException.class, () ->
                receipt.addTaxes(BigDecimal.valueOf(10))
        );
    }

    // ===== Tests para getTotal =====

    @Test
    @DisplayName("Cálculo total con un producto")
    public void testCalculateTotalWithTaxes() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(100));
        receipt.addLine("P001", 1);
        receipt.addTaxes(BigDecimal.valueOf(21));

        assertEquals(BigDecimal.valueOf(121), receipt.getTotal());
    }

    @Test
    @DisplayName("Cálculo total con múltiples productos")
    public void testComplexReceipt() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("LAPTOP", BigDecimal.valueOf(500));
        mockDB.addProduct("MOUSE", BigDecimal.valueOf(15));
        mockDB.addProduct("TECLADO", BigDecimal.valueOf(50));

        receipt.addLine("LAPTOP", 1);
        receipt.addLine("MOUSE", 2);
        receipt.addLine("TECLADO", 1);

        // Subtotal: 500 + 15*2 + 50 = 500 + 30 + 50 = 580
        // Impuesto 21%: 580 * 0.21 = 121.80
        // Total: 580 + 121.80 = 701.80

        receipt.addTaxes(BigDecimal.valueOf(21));

        assertEquals(BigDecimal.valueOf(701.80), receipt.getTotal());
    }

    @Test
    @DisplayName("Total vacío antes de aplicar impuestos")
    public void testGetTotalBeforeTaxes() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(100));
        receipt.addLine("P001", 1);

        assertEquals(BigDecimal.ZERO, receipt.getTotal());
    }

    @Test
    @DisplayName("Recibo con precios decimales")
    public void testReceiptWithDecimalPrices() throws DoesNotExistException, IsClosedException {
        mockDB.addProduct("P001", BigDecimal.valueOf(10.99));
        mockDB.addProduct("P002", BigDecimal.valueOf(5.50));

        receipt.addLine("P001", 2);
        receipt.addLine("P002", 3);

        // Subtotal: 10.99*2 + 5.50*3 = 21.98 + 16.50 = 38.48
        // Impuesto 21%: 38.48 * 0.21 = 8.0808 ≈ 8.08
        // Total: 38.48 + 8.08 = 46.56

        receipt.addTaxes(BigDecimal.valueOf(21));

        assertEquals(BigDecimal.valueOf(46.56), receipt.getTotal());
    }

    @Test
    @DisplayName("Mock de BD se mantiene aislado entre tests")
    public void testMockIsolation() throws DoesNotExistException, IsClosedException {
        // Este test verifica que setUp() reinicia el mock
        mockDB.addProduct("P001", BigDecimal.valueOf(100));
        receipt.addLine("P001", 1);
        receipt.addTaxes(BigDecimal.valueOf(10));

        assertEquals(BigDecimal.valueOf(110), receipt.getTotal());
    }
}