package com.receipt;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

@DisplayName("Tests para Receipt")
public class ReceiptTest {
    private Receipt receipt;

    @BeforeEach
    public void setUp() {
        receipt = new Receipt();
    }

    // ===== Tests para addLine =====

    @Test
    @DisplayName("Agregar una línea al recibo")
    public void testAddSingleLine() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(10), 2);
        assertFalse(receipt.isClosed());
    }

    @Test
    @DisplayName("Agregar múltiples líneas al recibo")
    public void testAddMultipleLines() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(10), 1);
        receipt.addLine(BigDecimal.valueOf(20), 2);
        receipt.addLine(BigDecimal.valueOf(5), 3);
        assertFalse(receipt.isClosed());
    }

    @Test
    @DisplayName("Agregar línea con cero unidades")
    public void testAddLineWithZeroUnits() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(10), 0);
        assertEquals(BigDecimal.ZERO, receipt.getTotal());
    }

    @Test
    @DisplayName("Excepción si se agrega línea cuando recibo está cerrado")
    public void testAddLineAfterClosing() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        receipt.addTaxes(BigDecimal.valueOf(21));
        assertThrows(IsClosedException.class, () ->
                receipt.addLine(BigDecimal.valueOf(50), 1)
        );
    }

    @Test
    @DisplayName("Excepción si pricePerUnit es null")
    public void testAddLineWithNullPrice() {
        assertThrows(IllegalArgumentException.class, () ->
                receipt.addLine(null, 5)
        );
    }

    @Test
    @DisplayName("Excepción si numUnits es negativo")
    public void testAddLineWithNegativeUnits() {
        assertThrows(IllegalArgumentException.class, () ->
                receipt.addLine(BigDecimal.valueOf(10), -1)
        );
    }

    // ===== Tests para addTaxes =====

    @Test
    @DisplayName("Agregar impuestos cierra el recibo")
    public void testAddTaxes() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        receipt.addTaxes(BigDecimal.valueOf(21));
        assertTrue(receipt.isClosed());
    }

    @Test
    @DisplayName("Excepción si se aplican impuestos dos veces")
    public void testAddTaxesAfterClosing() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        receipt.addTaxes(BigDecimal.valueOf(21));
        assertThrows(IsClosedException.class, () ->
                receipt.addTaxes(BigDecimal.valueOf(10))
        );
    }

    @Test
    @DisplayName("Excepción si porcentaje es null")
    public void testAddTaxesWithNullPercent() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        assertThrows(IllegalArgumentException.class, () ->
                receipt.addTaxes(null)
        );
    }

    @Test
    @DisplayName("Excepción si porcentaje es negativo")
    public void testAddTaxesWithNegativePercent() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        assertThrows(IllegalArgumentException.class, () ->
                receipt.addTaxes(BigDecimal.valueOf(-5))
        );
    }

    // ===== Tests para getTotal =====

    @Test
    @DisplayName("Total antes de agregar líneas es cero")
    public void testGetTotalEmpty() {
        assertEquals(BigDecimal.ZERO, receipt.getTotal());
    }

    @Test
    @DisplayName("Total antes de aplicar impuestos es cero")
    public void testGetTotalWithoutTaxes() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(10), 2);
        assertEquals(BigDecimal.ZERO, receipt.getTotal());
    }

    @Test
    @DisplayName("Total después de aplicar impuestos es correcto")
    public void testGetTotalWithTaxes() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        receipt.addTaxes(BigDecimal.valueOf(21));
        assertEquals(BigDecimal.valueOf(121), receipt.getTotal());
    }

    @Test
    @DisplayName("getTotal puede llamarse en cualquier momento")
    public void testGetTotalCanBeCalledAnytime() throws IsClosedException {
        BigDecimal total1 = receipt.getTotal();
        receipt.addLine(BigDecimal.valueOf(100), 1);
        BigDecimal total2 = receipt.getTotal();
        receipt.addTaxes(BigDecimal.valueOf(21));
        BigDecimal total3 = receipt.getTotal();

        assertEquals(BigDecimal.ZERO, total1);
        assertEquals(BigDecimal.ZERO, total2);
        assertEquals(BigDecimal.valueOf(121), total3);
    }

    // ===== Tests de Cálculo =====

    @Test
    @DisplayName("Cálculo correcto de impuesto al 21%")
    public void testTaxCalculation21Percent() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        receipt.addTaxes(BigDecimal.valueOf(21));

        BigDecimal expected = BigDecimal.valueOf(121);
        assertEquals(expected, receipt.getTotal());
    }

    @Test
    @DisplayName("Cálculo correcto de impuesto al 10%")
    public void testTaxCalculation10Percent() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(100), 1);
        receipt.addTaxes(BigDecimal.valueOf(10));

        BigDecimal expected = BigDecimal.valueOf(110);
        assertEquals(expected, receipt.getTotal());
    }

    @Test
    @DisplayName("Cálculo correcto con múltiples líneas")
    public void testComplexReceipt() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(15.50), 2);
        receipt.addLine(BigDecimal.valueOf(20), 1);
        receipt.addLine(BigDecimal.valueOf(5.25), 4);

        // Subtotal: 15.50*2 + 20*1 + 5.25*4 = 31 + 20 + 21 = 72
        // Impuesto 21%: 72 * 0.21 = 15.12
        // Total: 72 + 15.12 = 87.12

        receipt.addTaxes(BigDecimal.valueOf(21));

        BigDecimal expected = BigDecimal.valueOf(87.12);
        assertEquals(expected, receipt.getTotal());
    }

    @Test
    @DisplayName("Cálculo con decimales y redondeo")
    public void testReceiptWithDecimals() throws IsClosedException {
        receipt.addLine(BigDecimal.valueOf(10.99), 3);
        receipt.addTaxes(BigDecimal.valueOf(21));

        // Subtotal: 10.99 * 3 = 32.97
        // Impuesto: 32.97 * 0.21 = 6.9237 ≈ 6.92
        // Total: 32.97 + 6.92 = 39.89

        BigDecimal expected = BigDecimal.valueOf(39.89);
        assertEquals(expected, receipt.getTotal());
    }
}